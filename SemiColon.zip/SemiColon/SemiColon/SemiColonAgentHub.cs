﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using Newtonsoft.Json.Linq;

namespace SemiColon
{
    public class SemiColonAgentHub : Hub
    {

        public override System.Threading.Tasks.Task OnConnected()
        {
            Global.Agents.Add(new Core.Agent() { ConnectionId = Context.ConnectionId });
            return base.OnConnected();
        }

        public void GetDetail()
        {
            Clients.All.GetCustomerList(GetCustomerJSONString());
        }

        public string GetCustomerJSONString()
        {
            JObject obj = new JObject(
                new JProperty("customerList", new JArray(
                    from a in Global.Customers
                    
                    select new JObject(
                        new JProperty("text", a.Name + " : " + a.ContactNumber),
                        new JProperty("conectionId", a.ConnectionId)
                        )
                    ))
                );
            return obj.ToString();
        }

        public void HandShake(string connectionId)
        {
            Core.Customer customer = Global.Customers.Where(x => x.ConnectionId == connectionId).FirstOrDefault();
            customer.Status = Core.CustomerStatus.OnCall;
            Clients.All.StartConnection(connectionId, customer.Message);
        }

        public void SendToCustomer(string connectionId, string message)
        {
            Core.Agent agent = Global.Agents.Where(x => x.ConnectionId == connectionId).FirstOrDefault();
            Clients.All.SetAgentOffer(connectionId, message);
        }
    }
}
﻿//Variable for starting session
var customerVideo = document.getElementById("customerVideo");
var agentVideo = document.getElementById("agentVideo");

//Step 3: Create SignalR Connection
var signal = $.connection.semiColonHub;
var ready = false;


//Step 1: Create a RTCPeerConnection

//Create new RTCPeerConnection Start

var isChrome = !!navigator.webkitGetUserMedia;//Check for chrome
var STUN = { url: isChrome ? 'stun:stun.l.google.com:19302' : 'stun:23.21.150.121' };/*SESSION TRAVERSAL UTILITIES FOR NAT
A network protocol to allow an end host to discover its public IP address
*/
var iceServers = { iceServers: [STUN] };

var sdpConstraints = {
    'mandatory': {
        'OfferToReceiveAudio': true,
        'OfferToReceiveVideo': true
    }
};
var DtlsSrtpKeyAgreement = { DtlsSrtpKeyAgreement: true };
var optional = { optional: [DtlsSrtpKeyAgreement] };
var connection = new RTCPeerConnection(iceServers, optional);
//Create new RTCPeerConnection Ends

//Step 4
signal.client.getAgentOffer = function (from, cnt, message) {
    console.log("from " + from + " name " + name);
    if (from != name) {
        console.log("Received message" + message);
        remoteSDP = new RTCSessionDescription(JSON.parse(message));
        connection.setRemoteDescription(remoteSDP, function () {
            connection.createAnswer(getSDP, function (e) {
                console.log("Answer failed");
            }, sdpConstraints);
        }, function (e) {
            console.log("remote sdp failed" + e);
        });
    }
}

//Step 2: Create helper method for RTCPeerConection

//2.1 For showing video when we get stream from remote
connection.onaddstream = function (evt) {    
    attachMediaStream(agentVideo, evt.stream);
};


//2.2 ICECandidate
var OnICE = function (event) {
    var candidate = event.candidate;
    if (candidate === null) {        
        send_SDP();
    }
};

//2.3 Handel offer
var getSDP = function (obj) {    
    connection.setLocalDescription(obj);
}

//2.4 Send SDP
function send_SDP() {
    sendMessage(JSON.stringify(connection.localDescription));
}


//Step Send data to server
var sendMessage = function (message) {
    //message : connection.localDescription
    if (!ready)
        setTimeout(sendMessage, 100, message);
    else {        
        signal.server.sendFromCustomer(customerName, customerContact, message);
    }
}

var name = "Caller";

//Initialize RTCPeerConnection after getUserMedia Success
function gotLocalStream(stream) {
    //Attach video to Customer Video tag
    attachMediaStream(customerVideo, stream);
    connection.addStream(stream);
    connection.onicecandidate = OnICE;
    connection.createOffer(getSDP, function () { alert("could not create sdp"); }, sdpConstraints);
}

//Step Start Hub
$.connection.hub.start({ transport: ['longPolling'] }).done(function () {
    ready = true;
});


//Function for starting connection
function initializeSession()
{
    var customerName = document.getElementById("TBName").value;
    var customerContact = document.getElementById("TBContact").value;
    //Do form validation    

    //Start video session
    getUserMedia({ "audio": true, "video": true }, gotLocalStream, function (error) { console.log(error); alert("Could not get media"); });
}
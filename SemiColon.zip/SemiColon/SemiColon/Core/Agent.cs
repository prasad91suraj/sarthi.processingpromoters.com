﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SemiColon.Core
{
    public class Agent
    {
        public string  ConnectionId { get; set; }
        public bool IsAvailable { get; set; }
        public Agent()
        {
            IsAvailable = false;
        }
    }
}
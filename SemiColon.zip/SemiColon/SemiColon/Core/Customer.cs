﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SemiColon.Core
{
    public enum CustomerStatus
    {
        Uninitialize,
        Waiting,
        OnCall,
        Disconnected
    }

    public class Customer
    {
        public string ConnectionId { get; set; }
        public string Name { get; set; }
        public string ContactNumber { get; set; }
        public string Message { get; set; }
        public CustomerStatus Status { get; set; }

        public Customer()
        {
           this.Status = CustomerStatus.Uninitialize;
        }
    }
}
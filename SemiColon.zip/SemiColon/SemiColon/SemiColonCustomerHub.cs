﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace SemiColon
{
    public class SemiColonCustomerHub : Hub
    {
        public override System.Threading.Tasks.Task OnConnected()
        {
            Global.Customers.Add(new Core.Customer() { ConnectionId = Context.ConnectionId });
            return base.OnConnected();
        }

        public void SendFromCustomer(string customerName, string customerContact, string message)
        {            
            Core.Customer customer = Global.Customers.Where(x => x.ConnectionId == Context.ConnectionId).FirstOrDefault();
            customer.Name = customerName;
            customer.ContactNumber = customerContact;
            customer.Message = message;
            if((customerName.Trim()!="")&&(customerContact.Trim()!=""))
                customer.Status = Core.CustomerStatus.Waiting;
        }        
    }
}